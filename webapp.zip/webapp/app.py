from flask import Flask, request, redirect, url_for, render_template

app = Flask(__name__)
 
import soundfile as sf
import numpy as np
import librosa
from scipy.signal import butter, lfilter
import pickle
from tensorflow import keras
from sklearn import preprocessing
from sklearn.preprocessing import OneHotEncoder
import pandas as pd
import speech_recognition as sr

import warnings
warnings.filterwarnings("ignore")

def normalize_audio(audio):
    audio = audio / np.max(np.abs(audio))
    return audio

def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a

def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    y = lfilter(b, a, data)
    return y

def get_mfcc(signal, sr):
    mfcc = librosa.feature.mfcc(signal, n_mfcc=5, sr = sr)
    delta_mfcc = librosa.feature.delta(mfcc)
    delta2_mfcc = librosa.feature.delta(mfcc, order=2)
    combined_mfccs = np.concatenate((mfcc, delta_mfcc, delta2_mfcc))
    combined_mfccs = np.mean(combined_mfccs.T,axis=0)
    return combined_mfccs.tolist()

def feature_extraction(file):
    
    sound_list = []
    lowcut = 300
    highcut = 3000
    
    data, sr = sf.read(file)
    data_nor = normalize_audio(data)
    filtered_data = butter_bandpass_filter(data_nor, lowcut, highcut, sr, order=5)
    mfcc = get_mfcc(filtered_data,sr)
    sound_list.append(mfcc)
    sound_list[0].append(1)
    sound_list[0].append(0)
    
    return sound_list[0]

print("Loading model") 

global model_svm, model_mlp, model_lstm
model_svm = pickle.load(open("models\\svm.sav", 'rb'))
model_mlp = keras.models.load_model("models\\mlp")
model_lstm = keras.models.load_model("models\\lstm")

@app.route("/", methods=["GET", "POST"])
def main():
    prediction = ""
    if request.method == "POST":
        if "file" not in request.files:
            return redirect(request.url)

        file = request.files["file"]
        if file.filename == "":
            return redirect(request.url)

        if file:
            #get sound features
            X_train = pd.read_csv("models\\train.csv")
            X_test = pd.read_csv("models\\test.csv")
            X_test.loc[len(X_test.index)] = feature_extraction(file)

            #Scaling features
            scaler = preprocessing.StandardScaler()
            X_train = scaler.fit_transform(X_train)
            X_test = scaler.transform(X_test)
            X_test_lstm = np.reshape(X_test, (X_test.shape[0], 1, X_test.shape[1]))

            #One Hot Encoder
            df = pd.DataFrame(['de','en','es'],columns =['language'])
            one_hot_encoder = OneHotEncoder()
            one_hot_encoder.fit_transform(df['language'].to_numpy().reshape(-1, 1))

            #get models
            loaded_model_svm = pickle.load(open("models/svm.sav", 'rb'))
            loaded_model_mlp = keras.models.load_model("models/mlp")
            loaded_model_lstm = keras.models.load_model("models/lstm")

            #get ouput
            output_svm = loaded_model_svm.predict(X_test)
            output_mlp = one_hot_encoder.inverse_transform(loaded_model_mlp.predict(X_test))
            output_lstm = one_hot_encoder.inverse_transform(loaded_model_lstm.predict(X_test_lstm))
            
            output_mlp_check = loaded_model_mlp.predict(X_test)[len(loaded_model_mlp.predict(X_test))-1]

            if(output_mlp_check[2]==1.00):
                if(output_mlp_check[0]<pow(10,-20) and output_mlp_check[1]<pow(10,-20)):
                    output = [output_svm[len(output_svm)-1],'other','other']
                elif(output_mlp_check[0]>pow(10,-19)):
                    output = [output_svm[len(output_svm)-1],'de','de']
                elif(max(output_mlp_check[0],output_mlp_check[1])==output_mlp_check[0]):
                    output = [output_svm[len(output_svm)-1],'de','de']
                else:
                    output = [output_svm[len(output_svm)-1],'en','en']
            else:
                output = [output_svm[len(output_svm)-1],output_mlp[len(output_mlp)-1][0],output_lstm[len(output_lstm)-1][0]]

            if(output.count('de')>=2):
                prediction = "Deutesh"
            elif(output.count('en')>=2):
                prediction = "English"
            elif(output.count('es')>=2):
                prediction = "Espansol"
            else:
                prediction = "Other Language"
                

    return render_template('main.html', prediction=prediction)

@app.route("/record", methods=["GET", "POST"])
def record():
    return render_template('record.html')


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
